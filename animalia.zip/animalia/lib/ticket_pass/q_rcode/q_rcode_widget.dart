import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'q_rcode_model.dart';
export 'q_rcode_model.dart';

class QRcodeWidget extends StatefulWidget {
  const QRcodeWidget({
    Key? key,
    this.yep,
  }) : super(key: key);

  final QrcodeRecord? yep;

  @override
  _QRcodeWidgetState createState() => _QRcodeWidgetState();
}

class _QRcodeWidgetState extends State<QRcodeWidget> {
  late QRcodeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => QRcodeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        leading: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            context.goNamed(
              'ticketpassorder',
              queryParameters: {
                'qrcode': serializeParam(
                  widget.yep,
                  ParamType.Document,
                ),
              }.withoutNulls,
              extra: <String, dynamic>{
                'qrcode': widget.yep,
              },
            );
          },
          child: Icon(
            Icons.arrow_back_rounded,
            color: FlutterFlowTheme.of(context).black600,
            size: 40.0,
          ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Stack(
        children: [
          Align(
            alignment: AlignmentDirectional(0.05, -0.25),
            child: BarcodeWidget(
              data: widget.yep!.qrcodeValue,
              barcode: Barcode.qrCode(),
              width: 300.0,
              height: 300.0,
              color: FlutterFlowTheme.of(context).primaryText,
              backgroundColor: Colors.transparent,
              errorBuilder: (_context, _error) => SizedBox(
                width: 300.0,
                height: 300.0,
              ),
              drawText: false,
            ),
          ),
        ],
      ),
    );
  }
}
