import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MerchUserReceiptRecord extends FirestoreRecord {
  MerchUserReceiptRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "recieptID" field.
  String? _recieptID;
  String get recieptID => _recieptID ?? '';
  bool hasRecieptID() => _recieptID != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "price" field.
  String? _price;
  String get price => _price ?? '';
  bool hasPrice() => _price != null;

  // "item" field.
  List<String>? _item;
  List<String> get item => _item ?? const [];
  bool hasItem() => _item != null;

  // "loyaltypoint" field.
  int? _loyaltypoint;
  int get loyaltypoint => _loyaltypoint ?? 0;
  bool hasLoyaltypoint() => _loyaltypoint != null;

  void _initializeFields() {
    _recieptID = snapshotData['recieptID'] as String?;
    _date = snapshotData['date'] as DateTime?;
    _email = snapshotData['email'] as String?;
    _price = snapshotData['price'] as String?;
    _item = getDataList(snapshotData['item']);
    _loyaltypoint = castToType<int>(snapshotData['loyaltypoint']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('merch_user_receipt');

  static Stream<MerchUserReceiptRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MerchUserReceiptRecord.fromSnapshot(s));

  static Future<MerchUserReceiptRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => MerchUserReceiptRecord.fromSnapshot(s));

  static MerchUserReceiptRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MerchUserReceiptRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MerchUserReceiptRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MerchUserReceiptRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MerchUserReceiptRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MerchUserReceiptRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMerchUserReceiptRecordData({
  String? recieptID,
  DateTime? date,
  String? email,
  String? price,
  int? loyaltypoint,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'recieptID': recieptID,
      'date': date,
      'email': email,
      'price': price,
      'loyaltypoint': loyaltypoint,
    }.withoutNulls,
  );

  return firestoreData;
}

class MerchUserReceiptRecordDocumentEquality
    implements Equality<MerchUserReceiptRecord> {
  const MerchUserReceiptRecordDocumentEquality();

  @override
  bool equals(MerchUserReceiptRecord? e1, MerchUserReceiptRecord? e2) {
    const listEquality = ListEquality();
    return e1?.recieptID == e2?.recieptID &&
        e1?.date == e2?.date &&
        e1?.email == e2?.email &&
        e1?.price == e2?.price &&
        listEquality.equals(e1?.item, e2?.item) &&
        e1?.loyaltypoint == e2?.loyaltypoint;
  }

  @override
  int hash(MerchUserReceiptRecord? e) => const ListEquality().hash(
      [e?.recieptID, e?.date, e?.email, e?.price, e?.item, e?.loyaltypoint]);

  @override
  bool isValidKey(Object? o) => o is MerchUserReceiptRecord;
}
