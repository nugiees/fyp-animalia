import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MarkeersRecord extends FirestoreRecord {
  MarkeersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "video" field.
  String? _video;
  String get video => _video ?? '';
  bool hasVideo() => _video != null;

  // "desc" field.
  String? _desc;
  String get desc => _desc ?? '';
  bool hasDesc() => _desc != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  void _initializeFields() {
    _location = snapshotData['location'] as LatLng?;
    _name = snapshotData['name'] as String?;
    _video = snapshotData['video'] as String?;
    _desc = snapshotData['desc'] as String?;
    _category = snapshotData['category'] as String?;
    _image = snapshotData['image'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('markeers');

  static Stream<MarkeersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MarkeersRecord.fromSnapshot(s));

  static Future<MarkeersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MarkeersRecord.fromSnapshot(s));

  static MarkeersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MarkeersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MarkeersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MarkeersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MarkeersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MarkeersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMarkeersRecordData({
  LatLng? location,
  String? name,
  String? video,
  String? desc,
  String? category,
  String? image,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'location': location,
      'name': name,
      'video': video,
      'desc': desc,
      'category': category,
      'image': image,
    }.withoutNulls,
  );

  return firestoreData;
}

class MarkeersRecordDocumentEquality implements Equality<MarkeersRecord> {
  const MarkeersRecordDocumentEquality();

  @override
  bool equals(MarkeersRecord? e1, MarkeersRecord? e2) {
    return e1?.location == e2?.location &&
        e1?.name == e2?.name &&
        e1?.video == e2?.video &&
        e1?.desc == e2?.desc &&
        e1?.category == e2?.category &&
        e1?.image == e2?.image;
  }

  @override
  int hash(MarkeersRecord? e) => const ListEquality()
      .hash([e?.location, e?.name, e?.video, e?.desc, e?.category, e?.image]);

  @override
  bool isValidKey(Object? o) => o is MarkeersRecord;
}
