import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class QrcodeRecord extends FirestoreRecord {
  QrcodeRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "qrcode_value" field.
  String? _qrcodeValue;
  String get qrcodeValue => _qrcodeValue ?? '';
  bool hasQrcodeValue() => _qrcodeValue != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _qrcodeValue = snapshotData['qrcode_value'] as String?;
    _date = snapshotData['date'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('qrcode');

  static Stream<QrcodeRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => QrcodeRecord.fromSnapshot(s));

  static Future<QrcodeRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => QrcodeRecord.fromSnapshot(s));

  static QrcodeRecord fromSnapshot(DocumentSnapshot snapshot) => QrcodeRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static QrcodeRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      QrcodeRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'QrcodeRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is QrcodeRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createQrcodeRecordData({
  String? email,
  String? qrcodeValue,
  DateTime? date,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'qrcode_value': qrcodeValue,
      'date': date,
    }.withoutNulls,
  );

  return firestoreData;
}

class QrcodeRecordDocumentEquality implements Equality<QrcodeRecord> {
  const QrcodeRecordDocumentEquality();

  @override
  bool equals(QrcodeRecord? e1, QrcodeRecord? e2) {
    return e1?.email == e2?.email &&
        e1?.qrcodeValue == e2?.qrcodeValue &&
        e1?.date == e2?.date;
  }

  @override
  int hash(QrcodeRecord? e) =>
      const ListEquality().hash([e?.email, e?.qrcodeValue, e?.date]);

  @override
  bool isValidKey(Object? o) => o is QrcodeRecord;
}
