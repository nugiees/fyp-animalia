import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MerchandiseRecord extends FirestoreRecord {
  MerchandiseRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "desc" field.
  String? _desc;
  String get desc => _desc ?? '';
  bool hasDesc() => _desc != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  // "loyaltypoint" field.
  int? _loyaltypoint;
  int get loyaltypoint => _loyaltypoint ?? 0;
  bool hasLoyaltypoint() => _loyaltypoint != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _desc = snapshotData['desc'] as String?;
    _image = snapshotData['image'] as String?;
    _price = castToType<double>(snapshotData['price']);
    _loyaltypoint = castToType<int>(snapshotData['loyaltypoint']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('merchandise');

  static Stream<MerchandiseRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MerchandiseRecord.fromSnapshot(s));

  static Future<MerchandiseRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MerchandiseRecord.fromSnapshot(s));

  static MerchandiseRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MerchandiseRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MerchandiseRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MerchandiseRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MerchandiseRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MerchandiseRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMerchandiseRecordData({
  String? name,
  String? desc,
  String? image,
  double? price,
  int? loyaltypoint,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'desc': desc,
      'image': image,
      'price': price,
      'loyaltypoint': loyaltypoint,
    }.withoutNulls,
  );

  return firestoreData;
}

class MerchandiseRecordDocumentEquality implements Equality<MerchandiseRecord> {
  const MerchandiseRecordDocumentEquality();

  @override
  bool equals(MerchandiseRecord? e1, MerchandiseRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.desc == e2?.desc &&
        e1?.image == e2?.image &&
        e1?.price == e2?.price &&
        e1?.loyaltypoint == e2?.loyaltypoint;
  }

  @override
  int hash(MerchandiseRecord? e) => const ListEquality()
      .hash([e?.name, e?.desc, e?.image, e?.price, e?.loyaltypoint]);

  @override
  bool isValidKey(Object? o) => o is MerchandiseRecord;
}
