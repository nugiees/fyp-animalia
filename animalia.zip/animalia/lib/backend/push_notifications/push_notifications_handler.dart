import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '../backend.dart';
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    if (mounted) {
      setState(() => _loading = true);
    }
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        context.pushNamed(
          initialPageName,
          pathParameters: parameterData.pathParameters,
          extra: parameterData.extra,
        );
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  void initState() {
    super.initState();
    handleOpenedPushNotification();
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: Color(0xFF0D101F),
          child: Image.asset(
            'assets/images/Screenshot_20230323_033446_edited.jpg',
            fit: BoxFit.contain,
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'HomePage': (data) async => ParameterData(
        allParams: {
          'marker': await getDocumentParameter<MarkeersRecord>(
              data, 'marker', MarkeersRecord.fromSnapshot),
          'whatever': await getDocumentParameter<UsersRecord>(
              data, 'whatever', UsersRecord.fromSnapshot),
          'yep': await getDocumentParameter<MerchandiseRecord>(
              data, 'yep', MerchandiseRecord.fromSnapshot),
          'yes': await getDocumentParameter<QrcodeRecord>(
              data, 'yes', QrcodeRecord.fromSnapshot),
        },
      ),
  'AnimalList': (data) async => ParameterData(
        allParams: {
          'name': await getDocumentParameter<MarkeersRecord>(
              data, 'name', MarkeersRecord.fromSnapshot),
        },
      ),
  'QRcode': (data) async => ParameterData(
        allParams: {
          'yep': await getDocumentParameter<QrcodeRecord>(
              data, 'yep', QrcodeRecord.fromSnapshot),
        },
      ),
  'DetailLogin': (data) async => ParameterData(
        allParams: {
          'marker': await getDocumentParameter<MarkeersRecord>(
              data, 'marker', MarkeersRecord.fromSnapshot),
        },
      ),
  'DetailNotLogin': (data) async => ParameterData(
        allParams: {
          'marker': await getDocumentParameter<MarkeersRecord>(
              data, 'marker', MarkeersRecord.fromSnapshot),
        },
      ),
  'adminpage': (data) async => ParameterData(
        allParams: {
          'admin': await getDocumentParameter<UsersRecord>(
              data, 'admin', UsersRecord.fromSnapshot),
        },
      ),
  'adminanimalpage-edit': (data) async => ParameterData(
        allParams: {
          'animal': await getDocumentParameter<MarkeersRecord>(
              data, 'animal', MarkeersRecord.fromSnapshot),
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'alreadylogin': ParameterData.none(),
  'CreateAccount': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'LoginPage': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'directpage': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'directpageforadmin': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'directpageforqrcode': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'SuccessPayment': ParameterData.none(),
  'directpagehome': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'Checkout': (data) async => ParameterData(
        allParams: {
          'tets': await getDocumentParameter<MerchandiseRecord>(
              data, 'tets', MerchandiseRecord.fromSnapshot),
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'HomeProductList': (data) async => ParameterData(
        allParams: {
          'test': await getDocumentParameter<MerchandiseRecord>(
              data, 'test', MerchandiseRecord.fromSnapshot),
          'yt': await getDocumentParameter<UsersRecord>(
              data, 'yt', UsersRecord.fromSnapshot),
        },
      ),
  'ProductDetails': (data) async => ParameterData(
        allParams: {
          'merch': await getDocumentParameter<MerchandiseRecord>(
              data, 'merch', MerchandiseRecord.fromSnapshot),
          'ye': await getDocumentParameter<UsersRecord>(
              data, 'ye', UsersRecord.fromSnapshot),
        },
      ),
  'qrcodelanding': (data) async => ParameterData(
        allParams: {
          'qa': await getDocumentParameter<UsersRecord>(
              data, 'qa', UsersRecord.fromSnapshot),
        },
      ),
  'BuyTicket': (data) async => ParameterData(
        allParams: {
          'yes': await getDocumentParameter<UsersRecord>(
              data, 'yes', UsersRecord.fromSnapshot),
        },
      ),
  'ticketpassorder': (data) async => ParameterData(
        allParams: {
          'qrcode': await getDocumentParameter<QrcodeRecord>(
              data, 'qrcode', QrcodeRecord.fromSnapshot),
          'yep': await getDocumentParameter<UsersRecord>(
              data, 'yep', UsersRecord.fromSnapshot),
        },
      ),
  'SuccessPaymentMerch': ParameterData.none(),
  'adminanimalpage': (data) async => ParameterData(
        allParams: {
          'admin': await getDocumentParameter<UsersRecord>(
              data, 'admin', UsersRecord.fromSnapshot),
        },
      ),
  'adminviewticketpass': (data) async => ParameterData(
        allParams: {
          'admin': await getDocumentParameter<UsersRecord>(
              data, 'admin', UsersRecord.fromSnapshot),
        },
      ),
  'adminviewmerchitem': (data) async => ParameterData(
        allParams: {
          'admin': await getDocumentParameter<UsersRecord>(
              data, 'admin', UsersRecord.fromSnapshot),
        },
      ),
  'adminviewmerchitem-edit': (data) async => ParameterData(
        allParams: {
          'merch': await getDocumentParameter<MerchandiseRecord>(
              data, 'merch', MerchandiseRecord.fromSnapshot),
          'ye': await getDocumentParameter<UsersRecord>(
              data, 'ye', UsersRecord.fromSnapshot),
        },
      ),
  'adminmerchreceipt': (data) async => ParameterData(
        allParams: {
          'admin': await getDocumentParameter<UsersRecord>(
              data, 'admin', UsersRecord.fromSnapshot),
        },
      ),
  'AnimalDetail': (data) async => ParameterData(
        allParams: {
          'animal': await getDocumentParameter<MarkeersRecord>(
              data, 'animal', MarkeersRecord.fromSnapshot),
        },
      ),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
