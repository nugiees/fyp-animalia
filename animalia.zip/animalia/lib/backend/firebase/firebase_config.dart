import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDu0hPBfljQeDzxZ0-kWdlGvGqaRjL0JwA",
            authDomain: "animalia-fbff6.firebaseapp.com",
            projectId: "animalia-fbff6",
            storageBucket: "animalia-fbff6.appspot.com",
            messagingSenderId: "357101767611",
            appId: "1:357101767611:web:9c631f20a1507bfe71129e",
            measurementId: "G-0SGL1ZZ0FH"));
  } else {
    await Firebase.initializeApp();
  }
}
