import '/auth/base_auth_user_provider.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/adminpage/home_page/promo_card/promo_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'home_page_model.dart';
export 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({
    Key? key,
    this.marker,
    this.whatever,
    this.yep,
    this.yes,
  }) : super(key: key);

  final MarkeersRecord? marker;
  final UsersRecord? whatever;
  final MerchandiseRecord? yep;
  final QrcodeRecord? yes;

  @override
  _HomePageWidgetState createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  late HomePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomePageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await showModalBottomSheet(
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: false,
        context: context,
        builder: (context) {
          return GestureDetector(
            onTap: () =>
                FocusScope.of(context).requestFocus(_model.unfocusNode),
            child: Padding(
              padding: MediaQuery.viewInsetsOf(context),
              child: Container(
                height: 500.0,
                child: PromoCardWidget(),
              ),
            ),
          );
        },
      ).then((value) => setState(() {}));
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_model.unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          leading: InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              context.pushNamed(
                'AnimalList',
                queryParameters: {
                  'name': serializeParam(
                    widget.marker,
                    ParamType.Document,
                  ),
                }.withoutNulls,
                extra: <String, dynamic>{
                  'name': widget.marker,
                },
              );
            },
            child: Icon(
              Icons.list,
              color: FlutterFlowTheme.of(context).secondaryText,
              size: 24.0,
            ),
          ),
          title: Text(
            'Ragunan Zoo',
            textAlign: TextAlign.center,
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Poppins',
                  color: Colors.black,
                  fontSize: 22.0,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Stack(
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  if (responsiveVisibility(
                    context: context,
                    tablet: false,
                    tabletLandscape: false,
                    desktop: false,
                  ))
                    Expanded(
                      child: StreamBuilder<List<MarkeersRecord>>(
                        stream: queryMarkeersRecord(),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: SpinKitThreeBounce(
                                  color: Color(0xFF0D101F),
                                  size: 50.0,
                                ),
                              ),
                            );
                          }
                          List<MarkeersRecord> googleMapMarkeersRecordList =
                              snapshot.data!;
                          return FlutterFlowGoogleMap(
                            controller: _model.googleMapsController,
                            onCameraIdle: (latLng) => setState(
                                () => _model.googleMapsCenter = latLng),
                            initialLocation: _model.googleMapsCenter ??=
                                LatLng(-6.311578230728487, 106.82070801165365),
                            markers: googleMapMarkeersRecordList
                                .map(
                                  (googleMapMarkeersRecord) =>
                                      FlutterFlowMarker(
                                    googleMapMarkeersRecord.reference.path,
                                    googleMapMarkeersRecord.location!,
                                    () async {
                                      if (loggedIn) {
                                        context.pushNamed(
                                          'DetailLogin',
                                          queryParameters: {
                                            'marker': serializeParam(
                                              googleMapMarkeersRecord,
                                              ParamType.Document,
                                            ),
                                          }.withoutNulls,
                                          extra: <String, dynamic>{
                                            'marker': googleMapMarkeersRecord,
                                          },
                                        );
                                      } else {
                                        context.pushNamed(
                                          'DetailNotLogin',
                                          queryParameters: {
                                            'marker': serializeParam(
                                              googleMapMarkeersRecord,
                                              ParamType.Document,
                                            ),
                                          }.withoutNulls,
                                          extra: <String, dynamic>{
                                            'marker': googleMapMarkeersRecord,
                                          },
                                        );
                                      }
                                    },
                                  ),
                                )
                                .toList(),
                            markerColor: GoogleMarkerColor.violet,
                            mapType: MapType.normal,
                            style: GoogleMapStyle.silver,
                            initialZoom: 15.8,
                            allowInteraction: true,
                            allowZoom: true,
                            showZoomControls: false,
                            showLocation: true,
                            showCompass: false,
                            showMapToolbar: false,
                            showTraffic: false,
                            centerMapOnMarkerTap: true,
                          );
                        },
                      ),
                    ),
                ],
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.95),
                child: Container(
                  width: MediaQuery.sizeOf(context).width * 0.92,
                  height: 60.0,
                  decoration: BoxDecoration(
                    color: Color(0x00B32121),
                    borderRadius: BorderRadius.circular(0.0),
                  ),
                  child: Container(
                    width: 100.0,
                    height: 120.0,
                    child: Stack(
                      alignment:
                          AlignmentDirectional(0.0, 0.050000000000000044),
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              width: 100.0,
                              height: 60.0,
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(20.0),
                                border: Border.all(
                                  color: Color(0x00FFFFFF),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Align(
                          alignment: AlignmentDirectional(0.05, -0.05),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              FlutterFlowIconButton(
                                borderColor: Colors.transparent,
                                borderRadius: 30.0,
                                borderWidth: 1.0,
                                buttonSize: 50.0,
                                icon: Icon(
                                  Icons.qr_code,
                                  color: Color(0xFF9299A1),
                                  size: 28.0,
                                ),
                                onPressed: () async {
                                  context.pushNamed(
                                    'ticketpassorder',
                                    queryParameters: {
                                      'qrcode': serializeParam(
                                        widget.yes,
                                        ParamType.Document,
                                      ),
                                    }.withoutNulls,
                                    extra: <String, dynamic>{
                                      'qrcode': widget.yes,
                                    },
                                  );
                                },
                              ),
                              FlutterFlowIconButton(
                                borderColor: Colors.transparent,
                                borderRadius: 30.0,
                                borderWidth: 1.0,
                                buttonSize: 50.0,
                                icon: Icon(
                                  Icons.shopping_bag_outlined,
                                  color: Color(0xFF9299A1),
                                  size: 24.0,
                                ),
                                onPressed: () async {
                                  context.pushNamed('qrcodelanding');
                                },
                              ),
                              FlutterFlowIconButton(
                                borderColor: Colors.transparent,
                                borderRadius: 30.0,
                                borderWidth: 1.0,
                                buttonSize: 50.0,
                                icon: Icon(
                                  Icons.person,
                                  color: Color(0xFF9299A1),
                                  size: 26.0,
                                ),
                                onPressed: () async {
                                  context.pushNamed('directpage');
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
