import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

double decresed(double value) {
  return value * -1;
}

double incresevalueforcheckout(double value) {
  return value + 0.01;
}

int getPrice(double? price) {
  if (price == null) {
    return 0;
  }
  double ret = price * 100;
  return ret.toInt();
}

DateTime gettodaydate() {
  // get today date
  var now = new DateTime.now();
  var formatter = new DateFormat('yyyy-MM-dd');
  String formatted = formatter.format(now);
  return DateTime.parse(formatted);
}

double newCustomFunction(
  double sum,
  double? loyaltypoint,
) {
  // decresed value a with value b
  if (loyaltypoint == null) {
    return sum;
  }
  return sum - loyaltypoint;
}

bool showSearchResult2(
  String textSearchfor,
  String textSearchIn,
) {
  return textSearchIn.toLowerCase().contains(textSearchfor.toLowerCase());
}
